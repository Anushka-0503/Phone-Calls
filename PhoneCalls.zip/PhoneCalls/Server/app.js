require('dotenv').config()
const express = require('express')
const app = express()
const PORT = process.env.PORT
const cors= require('cors')
const phonecallController= require('./controllers/phoneCallController')

//Middlewares
app.use(cors())

//Routes
app.get('/getstatesdata',phonecallController.states_get_all)
app.get('/:name/:id',phonecallController.cities_get_ByID)
//  app.get('/getcitiesdata/:id/:page',phonecallController.cities_get_ByID)

//Server Connection
app.listen(PORT, () => {
    console.log('server started on port', PORT);
});
