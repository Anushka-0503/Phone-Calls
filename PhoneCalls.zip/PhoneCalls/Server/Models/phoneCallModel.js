const mysql = require('mysql')
const state_id= require('../controllers/phoneCallController')
const limit = 20

// require('dotenv').config({ path: '../.env'})
const db = mysql.createConnection({
    host: '188.166.17.187',
    user: 'testuser1',
    password: 'testt@1122##',
    database: 'phonecalls'
    // host:process.env.HOST,
    // user:process.env.USER,
    // password:process.env.PASSWORD,
    // database:process.env.DATABASE
})

db.connect((err) => {
    if (err) {
        throw err;
    }
    console.log('Mysql connected');
});

exports.callQuery=(query,callBackFunc)=>{
    db.query(query, (err, result) => {
      if(callBackFunc!==null)
      {
          callBackFunc(err,result)
      }
    })
}

exports.getStates=(req,callBackFunc)=>{
    let sqlQuery = 'SELECT * FROM states'
    this.callQuery(sqlQuery,callBackFunc)
}

exports.getCities=(req,callBackFunc)=>{
 const page= req.params.id
 const limit= 250
 console.log(typeof(page),page)
 const offset= (page-1)*limit 
 console.log(offset)
    console.log(req.params.name)
    // let sqlQuery=`select phone_code from cities where state= '${req.params.name}'`
    let sqlQuery= `select phone_code from cities where state= '${req.params.name}' limit ${limit} offset ${offset}`
    this.callQuery(sqlQuery,callBackFunc)
}




// module.exports={
//     db,
//     getStatesQuery,
//     getCitiesQuery
// }
    
