const model=require('../Models/phoneCallModel')
const ITEMS_PER_PAGE= 20

exports.states_get_all = (req, res, next) => {
    model.getStates(req,(error,response)=>{
      if(response)
      {
        res.send(response)
      }
      else{
        console.error(error)
        res.status(500)
        res.end()
      }
    })
}

exports.cities_get_ByID = (req,res,next)=>{
// console.log(req.params)
  model.getCities(req,(error,response)=>{
    if(response)
    {
      res.send(response)
    }
    else{
      console.error(error)
      res.status(500)
      res.end()
    }
  })
}

