<template>
  <div>
    <h1>Phone codes List</h1>
    <!-- <h2>{{$route.query.id}}</h2> -->
      <!-- <table border="1px" style="margin-left: auto; margin-right: auto"> -->
      <span v-for="item in list" v-bind:key="item.id">
        <!-- <td> -->
          <!-- <router-link :to="{path:'/cities',query:{id:item.id}}"> -->
          <!-- <router-link :to="{name: 'cities', params: {id: item.state}}"> -->
          <span>{{ item.phone_code }}</span>
          <span> | </span>
          <!-- </router-link> -->
        <!-- </td> -->
      </span>
    <!-- </table> -->
    <section class="pagination" style="text-align: center">
      <!-- <router-link :to="{ path: '/cities', query: { id: item.id } }"> -->
      <a
        v-on:click="decrementCount()"
        v-if="count !=0"
        :href="`?page=` + count"
        style="
          text-decoration: none;
          color: green;
          padding: 0.5rem;
          border: 1px solid green;
          margin: 0.1rem;
        "
        >Previous</a
      >
      <!-- </router-link> -->
      <!-- //this.list.length<250 href="#" else - Next
      //this.count==1?href="#" else  - previous -->
      <!-- <router-link :to="{ path: '/cities', query: { id: item.id } }"> -->
      <a
        v-on:click="incrementCount()"
        v-if="list?.length === 250"
        :href="`?page=` + count"
        style="
          text-decoration: none;
          color: green;
          padding: 0.5rem;
          border: 1px solid green;
          margin: 0.1rem;
        "
        >Next</a
      >
      <!-- </router-link> -->
    </section>
    <!-- <button v-on:click="next()">SEE MORE</button> -->
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "Cities",
  data() {
    return { list: undefined, count: 0 };
  },
  mounted() {
    const urlParams = new URLSearchParams(window.location.search);
    const statename = window.location.pathname.split("/")[1];
    const pageNo = urlParams.get("page");
    this.count = pageNo;
    console.log(this.count, "cc");
    axios.get(`http://localhost:5000/${statename}/${pageNo}`).then((res) => {
      this.list = res.data;
      console.log(this.list.length, "len");
    });
  },
  methods: {
    incrementCount() {
      this.count++;
    },
    decrementCount() {
      this.count--;
    },
  },
};
</script>
