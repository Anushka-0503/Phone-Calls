
<template>
    <div>
        <h1> State List </h1>
        <table border="1px" style="margin-left:auto; margin-right:auto">
            <tr>
                <td>State</td>
               
            </tr>
              <tr v-for= "item in list" v-bind:key="item.id">
                  <td>
                      <router-link :to="{path:`/${item.state}`,query:{page:`${1}`}}">
                      <!-- <router-link :to="{name: 'cities', params: {id: item.state}}"> -->
                         <h2>{{item.state}}</h2>
                      </router-link>
                  </td>
            </tr>
        </table>
    </div>
</template>

<script>
import axios from "axios";

export default {
  name: "StateList",
  data() {
    return { list: undefined };
  },
  mounted() {
    axios.get("http://localhost:5000/getstatesdata").then((res) => {
      this.list = res.data;
    });
  },
  methods: {
    goToHome(name, id) {
      console.log(name, id, "name and id");
    },
  },
};
</script>

