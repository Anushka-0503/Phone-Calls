import { createRouter, createWebHistory } from 'vue-router'
import StateList from '../components/States.vue'
import Cities from '../components/Cities.vue'

const routes = [
    {
        path: '/',
        name: 'StateList',
        component: StateList
    },
    {
        path: '/:name',
        name: 'Cities',
        component: Cities
    }
]
const router = createRouter({
    history: createWebHistory('/'), routes

})

export default router
